A bootloader is the piece of course which allow you to upload a new binary onto a board, usually over the serial port. Some boards, such as some MSP430-based boards, have a bootloader built-in. For others, you need to load some little program over JTAG. This directory contains such bootloaders for a couple of boards.

The code in this directory is NOT directly used in the OpenWSN stack.