#ifndef __GPIO_H
#define __GPIO_H

//=========================== defines =========================================

//=========================== variables =======================================

//=========================== prototypes ======================================

void GPIO_Config_ALL_AIN(void);
void GPIO_Configuration(void);

#endif
