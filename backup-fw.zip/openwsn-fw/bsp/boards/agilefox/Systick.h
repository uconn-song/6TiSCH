

void SysTick_Config(void);
extern unsigned char systik_i;
extern unsigned char rtc_sig,rtc_play;