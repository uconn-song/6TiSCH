/**
\brief ELDORADO-specific definition of the "uart" bsp module.

\author Branko Kerkez <bkerkez@berkeley.edu>, February 2012.
*/

//this compiles does not have stdint.h, but does the same in PE_Types.h
#include "PE_Types.h"